package maven_par;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

import junit.framework.Assert;

public class imdb {
	static {
		System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
	}
@SuppressWarnings("deprecation")
@Test
	public void test() throws InterruptedException { 
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://www.imdb.com/");
		Thread.sleep(5000);
		driver.findElement(By.id("suggestion-search")).sendKeys("pushpa the rise part-1");
		driver.findElement(By.id("iconContext-magnify")).click();
		driver.findElement(By.xpath("//a[text()='Pushpa: The Rise - Part 1']")).click();
		String releasedate1 = driver.findElement(By.xpath("//a[text()='Release date']/..")).getText();
		String country1=driver.findElement(By.xpath("//span[text()='Country of origin']/..")).getText();
		Reporter.log(releasedate1);
		Reporter.log(country1);
		driver.get("https://www.wikipedia.org/");
		driver.findElement(By.id("searchInput")).sendKeys("pushpa the rise part-1"+Keys.ENTER);
		driver.findElement(By.xpath("//a[@title='Pushpa: The Rise']")).click();
		String releasedate2 = driver.findElement(By.xpath("//div[text()='Release date']/../..")).getText();
		Reporter.log(releasedate2);
		String country2 = driver.findElement(By.xpath("//th[text()='Country']/..")).getText();
		driver.quit();
		Reporter.log(country2);
		Assert.assertEquals(releasedate1,releasedate2 );
		Assert.assertEquals(country1,country2 );
		
}
}
